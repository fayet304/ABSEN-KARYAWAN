// Modal controls
function openModal(id) {
  document.getElementById(id).style.display = "flex";
}

function closeModal(id) {
  document.getElementById(id).style.display = "none";
  // Reset messages and forms on close
  if(id === "modalDaftar") {
    document.getElementById("formDaftar").reset();
    document.getElementById("daftarMessage").textContent = "";
  }
  if(id === "modalLupa") {
    document.getElementById("formLupa").reset();
    document.getElementById("lupaMessage").textContent = "";
  }
}

// Tutup modal jika klik di luar konten modal
window.onclick = function(event) {
  const modalDaftar = document.getElementById("modalDaftar");
  const modalLupa = document.getElementById("modalLupa");
  if (event.target === modalDaftar) {
    closeModal('modalDaftar');
  }
  if (event.target === modalLupa) {
    closeModal('modalLupa');
  }
};

// Login & Register
window.onload = function () {
  const isLoggedIn = localStorage.getItem("isLoggedIn");
  if (isLoggedIn === "true") {
    document.getElementById("loginPage").style.display = "none";
    document.getElementById("menuPage").style.display = "flex";
    showPage("aktivitasBaru");
  }
  
  // Set up dummy activity data if none exists
  if (!localStorage.getItem("aktivitasKaryawan")) {
    const dummyAktivitas = [
      {
        nama: "admin",
        tanggal: "2025-08-01",
        waktu: "08:30",
        tipe: "Absen Masuk",
        shift: "Pagi",
        keterangan: "Tepat waktu"
      },
      {
        nama: "admin",
        tanggal: "2025-08-01",
        waktu: "17:00",
        tipe: "Absen Pulang",
        shift: "Pagi",
        keterangan: "Lembur 1 jam"
      },
      {
        nama: "john",
        tanggal: "2025-08-02",
        waktu: "09:10",
        tipe: "Absen Masuk",
        shift: "Pagi",
        keterangan: "Terlambat 10 menit"
      },
      {
        nama: "sarah",
        tanggal: "2025-08-03",
        waktu: "13:00",
        tipe: "Absen Masuk",
        shift: "Siang",
        keterangan: "Normal"
      },
      {
        nama: "admin",
        tanggal: "2025-08-04",
        waktu: "08:00",
        tipe: "Absen Masuk",
        shift: "Pagi",
        keterangan: "Datang lebih awal"
      }
    ];
    localStorage.setItem("aktivitasKaryawan", JSON.stringify(dummyAktivitas));
  }
};

window.handleLogin = function(e) {
  e.preventDefault();
  const username = document.getElementById('username').value.trim();
  const password = document.getElementById('password').value;

  // Cek akun di localStorage
  const users = JSON.parse(localStorage.getItem("userAccounts") || "[]");

  // Cek admin default jika tidak ada user terdaftar
  const adminUser = {username: "admin", password: "12345"};

  let userFound = users.find(u => u.username === username && u.password === password);
  if (!userFound && username === adminUser.username && password === adminUser.password) {
    userFound = adminUser;
  }

  if (userFound) {
    localStorage.setItem("isLoggedIn", "true");
    localStorage.setItem("currentUser", username);

    document.getElementById("loginPage").style.display = "none";
    document.getElementById("menuPage").style.display = "flex";

    // Simpan log login
    const logs = JSON.parse(localStorage.getItem("loginLogs") || "[]");
    const now = new Date();
    const waktu = now.toLocaleString('id-ID');
    const agent = /Mobi/i.test(navigator.userAgent) ? "Mobile Browser" : "Desktop Browser";
    const ip = "192.168.1." + Math.floor(Math.random() * 100 + 1);
    logs.push({ nama: username, waktu, agent, ip });
    localStorage.setItem("loginLogs", JSON.stringify(logs));

    showPage('aktivitasBaru');
  } else {
    alert("Login gagal! Username atau password salah.");
  }
};

window.handleDaftar = function(e) {
  e.preventDefault();
  const username = document.getElementById("daftarUsername").value.trim();
  const password = document.getElementById("daftarPassword").value;

  if (!username || !password) {
    alert("Username dan password wajib diisi!");
    return;
  }

  let users = JSON.parse(localStorage.getItem("userAccounts") || "[]");
  if (users.find(u => u.username === username)) {
    document.getElementById("daftarMessage").style.color = "red";
    document.getElementById("daftarMessage").textContent = "Username sudah terdaftar.";
    return;
  }

  users.push({username, password});
  localStorage.setItem("userAccounts", JSON.stringify(users));

  document.getElementById("daftarMessage").style.color = "green";
  document.getElementById("daftarMessage").textContent = "Akun berhasil didaftarkan! Silakan login.";
  document.getElementById("formDaftar").reset();

  // Auto-close modal setelah 2 detik
  setTimeout(() => closeModal('modalDaftar'), 2000);
};

window.handleLupa = function(e) {
  e.preventDefault();
  const username = document.getElementById("lupaUsername").value.trim();

  const users = JSON.parse(localStorage.getItem("userAccounts") || "[]");
  if (username === "admin") {
    document.getElementById("lupaMessage").style.color = "green";
    document.getElementById("lupaMessage").textContent = `Password admin adalah: 12345`;
    return;
  }
  const user = users.find(u => u.username === username);
  if (user) {
    document.getElementById("lupaMessage").style.color = "green";
    document.getElementById("lupaMessage").textContent = `Password untuk username "${username}" adalah: ${user.password}`;
  } else {
    document.getElementById("lupaMessage").style.color = "red";
    document.getElementById("lupaMessage").textContent = "Username tidak ditemukan.";
  }
};

// Menu dan konten
window.showPage = function(page) {
  const content = document.getElementById('contentArea');

  if (page === 'aktivitasBaru') {
    content.innerHTML = `
      <h1>Aktivitas Terbaru</h1>
      <div class="button-group">
        <button onclick="showShiftForm()">Absen Masuk</button>
        <button onclick="showIzinForm()">Izin</button>
        <button onclick="absenPulang()">Absen Pulang</button>
      </div>
      <div id="shiftFormContainer"></div>
      <div id="izinFormContainer"></div>
      <div id="welcomeMessageContainer"></div>
    `;
  }

  if (page === 'tambahPemain') {
    content.innerHTML = `
      <h1>Tambah Karyawan</h1>
      <form id="formTambahPemain" onsubmit="submitPemain(event)">
        <div class="form-group">
          <label for="namaLengkap">Nama Lengkap</label>
          <input type="text" id="namaLengkap" required />
        </div>
        <div class="form-group">
          <label for="emailPemain">Email</label>
          <input type="email" id="emailPemain" required />
        </div>
        <div class="form-group">
          <label for="keteranganPemain">Keterangan</label>
          <textarea id="keteranganPemain" rows="3"></textarea>
        </div>
        <button type="submit" class="btn-blue">Tambah Karyawan Baru</button>
      </form>
      <div id="formMessage" style="margin-top:10px; color:green;"></div>
      <div class="floating-box">
        <h3>Pencarian Data Karyawan</h3>
        <div class="form-group">
          <label>Nama Lengkap</label>
          <input type="text" id="searchNama" />
        </div>
        <div class="form-group">
          <label>Keterangan</label>
          <input type="text" id="searchKeterangan" />
        </div>
        <button onclick="searchKaryawan()" class="btn-blue">Cari</button>
        <div id="hasilCari"></div>
      </div>
      <h3>Data Karyawan Terdaftar</h3>
      <div id="dataTabel"></div>
    `;
    tampilkanSemuaKaryawan();
  }

  if (page === 'riwayatLogin') {
    const logs = JSON.parse(localStorage.getItem("loginLogs") || "[]");
    let rows = logs.map(log => `
      <tr>
        <td>${log.nama}</td>
        <td>${log.waktu}</td>
        <td>${log.agent}</td>
        <td>${log.ip}</td>
      </tr>
    `).join('');

    content.innerHTML = `
      <h1>Riwayat Login Karyawan</h1>
      <div class="floating-box">
        <h3>Pencarian Riwayat Login</h3>
        <form onsubmit="cariHistory(event)">
          <div class="form-group">
            <label for="inputHistoryNama">Nama Karyawan</label>
            <input type="text" id="inputHistoryNama" placeholder="Masukkan nama karyawan" />
          </div>
          <button type="submit" class="btn-blue">Cari Riwayat</button>
        </form>
        <div id="hasilHistory" style="margin-top: 15px;"></div>
      </div>
      <h3>Semua Riwayat Login</h3>
      <table>
        <thead>
          <tr>
            <th>Nama Karyawan</th>
            <th>Tanggal & Waktu</th>
            <th>Aplikasi Web Login</th>
            <th>IP Address</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `;
  }

  if (page === 'historyAktivitas') {
    content.innerHTML = `
      <h1>History Aktivitas Karyawan</h1>
      <div class="search-history-form">
        <h3>Pencarian Riwayat Aktivitas</h3>
        <form id="formSearchHistory" onsubmit="searchHistoryAktivitas(event)">
          <div class="form-group">
            <label for="searchHistoryNama">Nama Lengkap</label>
            <input type="text" id="searchHistoryNama" placeholder="Masukkan nama karyawan" />
          </div>
          <div class="form-group">
            <label for="searchHistoryTanggal">Tanggal Aktivitas (Opsional)</label>
            <input type="date" id="searchHistoryTanggal" />
          </div>
          <div class="form-group">
            <label for="searchHistoryTipe">Tipe Aktivitas (Opsional)</label>
            <select id="searchHistoryTipe">
              <option value="">-- Semua --</option>
              <option value="Absen Masuk">Absen Masuk</option>
              <option value="Absen Pulang">Absen Pulang</option>
              <option value="Izin">Izin</option>
            </select>
          </div>
          <button type="submit" class="btn-blue">Cari Riwayat</button>
        </form>
      </div>
      <div id="historyResults" class="search-history-result">
        <p>Masukkan nama karyawan dan klik cari untuk menampilkan riwayat aktivitas.</p>
      </div>
    `;
  }
};

// Function untuk mencari history aktivitas
window.searchHistoryAktivitas = function(e) {
  e.preventDefault();
  const nama = document.getElementById('searchHistoryNama').value.trim().toLowerCase();
  const tanggal = document.getElementById('searchHistoryTanggal').value;
  const tipe = document.getElementById('searchHistoryTipe').value;
  
  if (!nama) {
    alert("Harap masukkan nama karyawan!");
    return;
  }
  
  const aktivitas = JSON.parse(localStorage.getItem("aktivitasKaryawan") || "[]");
  
  // Filter berdasarkan nama (wajib), tanggal dan tipe (opsional)
  const filteredAktivitas = aktivitas.filter(item => {
    const matchNama = item.nama.toLowerCase().includes(nama);
    const matchTanggal = tanggal ? item.tanggal === tanggal : true;
    const matchTipe = tipe ? item.tipe === tipe : true;
    return matchNama && matchTanggal && matchTipe;
  });
  
  displayHistoryResults(filteredAktivitas);
};

function displayHistoryResults(results) {
  const resultsContainer = document.getElementById('historyResults');
  
  if (results.length === 0) {
    resultsContainer.innerHTML = `<div class="no-results">Tidak ditemukan data aktivitas untuk kriteria yang dipilih</div>`;
    return;
  }
  
  let html = '<h3>Hasil Pencarian</h3>';
  
  results.forEach(item => {
    html += `
      <div class="history-record">
        <h3>${item.nama}</h3>
        <div class="history-meta">
          ${item.tanggal} | ${item.waktu} | Shift: ${item.shift}
        </div>
        <div class="history-action">
          <strong>${item.tipe}</strong>: ${item.keterangan}
        </div>
      </div>
    `;
  });
  
  resultsContainer.innerHTML = html;
}

window.showShiftForm = function() {
  document.getElementById("shiftFormContainer").innerHTML = `
    <div class="shift-form">
      <label for="shiftSelect">Pilih Shift:</label>
      <select id="shiftSelect">
        <option value="Pagi">Shift Pagi</option>
        <option value="Siang">Shift Siang</option>
        <option value="Malam">Shift Malam</option>
      </select>
      <button onclick="submitShift()">Submit</button>
    </div>
  `;

  document.getElementById("izinFormContainer").innerHTML = "";
  document.getElementById("welcomeMessageContainer").innerHTML = "";
};

window.showIzinForm = function() {
  document.getElementById("izinFormContainer").innerHTML = `
    <div class="shift-form">
      <label for="izinKeterangan">Keterangan Izin:</label>
      <textarea id="izinKeterangan" rows="3" placeholder="Masukkan alasan izin"></textarea>
      <button onclick="submitIzin()">Submit Izin</button>
    </div>
  `;

  document.getElementById("shiftFormContainer").innerHTML = "";
  document.getElementById("welcomeMessageContainer").innerHTML = "";
};

window.submitShift = function() {
  const shift = document.getElementById("shiftSelect").value;
  const welcomeContainer = document.getElementById("welcomeMessageContainer");
  welcomeContainer.innerHTML = `
    <div id="welcomeMessage">
      Selamat datang! Anda telah absen masuk untuk shift <span style="color:#0099ff; font-weight:bold;">${shift}</span>.
    </div>
  `;
  document.getElementById("shiftFormContainer").innerHTML = "";
  
  // Simpan data aktivitas
  saveActivity("Absen Masuk", shift, "Tepat waktu");
};

window.submitIzin = function() {
  const keterangan = document.getElementById("izinKeterangan").value.trim();
  if (!keterangan) {
    alert("Keterangan izin wajib diisi!");
    return;
  }
  
  const welcomeContainer = document.getElementById("welcomeMessageContainer");
  welcomeContainer.innerHTML = `
    <div id="welcomeMessage" style="background-color:#fcf8e3; color:#8a6d3b;">
      Izin Anda telah dicatat dengan keterangan: <span style="font-weight:bold;">${keterangan}</span>.
    </div>
  `;
  document.getElementById("izinFormContainer").innerHTML = "";
  
  // Simpan data izin
  saveActivity("Izin", "-", keterangan);
};

window.absenPulang = function() {
  // Simpan aktivitas absen pulang
  saveActivity("Absen Pulang", "-", "Normal");
  
  const welcomeContainer = document.getElementById("welcomeMessageContainer");
  welcomeContainer.innerHTML = `
    <div id="welcomeMessage" style="background-color:#d9edf7; color:#31708f;">
      Absen pulang Anda telah berhasil dicatat pada ${new Date().toLocaleTimeString('id-ID')}
    </div>
  `;
  
  document.getElementById("shiftFormContainer").innerHTML = "";
  document.getElementById("izinFormContainer").innerHTML = "";
};

// Fungsi untuk menyimpan aktivitas
function saveActivity(tipe, shift, keterangan) {
  const username = localStorage.getItem("currentUser") || "unknown";
  const now = new Date();
  const aktivitasKaryawan = JSON.parse(localStorage.getItem("aktivitasKaryawan") || "[]");
  
  const newActivity = {
    nama: username,
    tanggal: now.toISOString().split('T')[0], // Format YYYY-MM-DD
    waktu: now.toLocaleTimeString('id-ID', {hour: '2-digit', minute:'2-digit'}),
    tipe: tipe,
    shift: shift,
    keterangan: keterangan
  };
  
  aktivitasKaryawan.push(newActivity);
  localStorage.setItem("aktivitasKaryawan", JSON.stringify(aktivitasKaryawan));
}

window.submitPemain = function(e) {
  e.preventDefault();
  const nama = document.getElementById('namaLengkap').value.trim();
  const email = document.getElementById('emailPemain').value.trim();
  const keterangan = document.getElementById('keteranganPemain').value.trim();

  if (!nama || !email) {
    alert("Nama dan Email wajib diisi!");
    return;
  }

  const data = JSON.parse(localStorage.getItem("dataKaryawan") || "[]");
  data.push({ nama, email, keterangan });
  localStorage.setItem("dataKaryawan", JSON.stringify(data));

  document.getElementById('formMessage').textContent = `Karyawan "${nama}" berhasil ditambahkan.`;
  document.getElementById('formTambahPemain').reset();
  tampilkanSemuaKaryawan();
};

window.tampilkanSemuaKaryawan = function() {
  const data = JSON.parse(localStorage.getItem("dataKaryawan") || "[]");
  if (data.length === 0) {
    document.getElementById("dataTabel").innerHTML = "<p>Tidak ada data karyawan terdaftar.</p>";
    return;
  }
  let html = "<table><thead><tr><th>Nama</th><th>Email</th><th>Keterangan</th></tr></thead><tbody>";
  data.forEach(d => {
    html += `<tr><td>${d.nama}</td><td>${d.email}</td><td>${d.keterangan}</td></tr>`;
  });
  html += "</tbody></table>";
  document.getElementById("dataTabel").innerHTML = html;
};

window.searchKaryawan = function() {
  const namaCari = document.getElementById("searchNama").value.toLowerCase();
  const ketCari = document.getElementById("searchKeterangan").value.toLowerCase();
  const data = JSON.parse(localStorage.getItem("dataKaryawan") || "[]");

  const hasil = data.filter(d =>
    d.nama.toLowerCase().includes(namaCari) &&
    d.keterangan.toLowerCase().includes(ketCari)
  );

  if (hasil.length === 0) {
    document.getElementById("hasilCari").innerHTML = "<p style='color:red;'>Data tidak ditemukan.</p>";
    return;
  }

  let html = "<table><thead><tr><th>Nama</th><th>Email</th><th>Keterangan</th></tr></thead><tbody>";
  hasil.forEach(d => {
    html += `<tr><td>${d.nama}</td><td>${d.email}</td><td>${d.keterangan}</td></tr>`;
  });
  html += "</tbody></table>";
  document.getElementById("hasilCari").innerHTML = html;
};

window.logout = function() {
  localStorage.removeItem("isLoggedIn");
  localStorage.removeItem("currentUser");
  location.reload();
};

window.cariHistory = function(e) {
  e.preventDefault();
  const nama = document.getElementById("inputHistoryNama").value.trim().toLowerCase();
  const logs = JSON.parse(localStorage.getItem("loginLogs") || "[]");

  const hasil = logs.filter(log => log.nama.toLowerCase().includes(nama));

  if (hasil.length === 0) {
    document.getElementById("hasilHistory").innerHTML = "<p style='color:red;'>Riwayat tidak ditemukan.</p>";
    return;
  }

  let html = `
    <table>
      <thead>
        <tr>
          <th>Nama</th>
          <th>Waktu</th>
          <th>Browser</th>
          <th>IP Address</th>
        </tr>
      </thead>
      <tbody>
  `;
  hasil.forEach(item => {
    html += `<tr>
      <td>${item.nama}</td>
      <td>${item.waktu}</td>
      <td>${item.agent}</td>
      <td>${item.ip}</td>
    </tr>`;
  });
  html += "</tbody></table>";

  document.getElementById("hasilHistory").innerHTML = html;
};